# Salesforce - LinkedIn-Integration
Hello All, I am back with another Integration post and in this post, I will show how you can connect with LinkedIn from your salesforce org using a small and smart piece of code.

So, Get ready to do another integration with Salesforce.

### New Changes 
Added the below functionality:

1 - Replaced the Custom Setting with the Custom object so that Access Token can be saved.
2 - Added a new method which is responsible for sharing the Post to LinkedIn Profile

